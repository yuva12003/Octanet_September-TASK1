# bank-atm-system
Three-way modelling of a bank-Atm-system between a customer\user,a database and an operator.
I created it as a GUI app using tkinter with python.
works with python's tkinter from python version 3.0 above,not usable with python 2.x versions.
